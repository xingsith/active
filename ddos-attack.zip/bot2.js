const mineflayer = require('mineflayer');

// Configuration for server and bot properties
const server = {
  host: '192.168.1.3', // Your server IP
  port: 25565            // Your server Port
};

// Function to create a bot with a unique username
function createBot(botNumber) {
  const bot = mineflayer.createBot({
    host: server.host,
    port: server.port,
    username: `puk_ah_kak${botNumber}`, // Unique username for each bot
  });

  bot.on('login', () => {
    console.log(`Bot ${bot.username} joined the server.`);
    // Make the bot perform an action, e.g., jump or chat
    setInterval(() => bot.chat("server doch ach server doch ach server doch ach"), 5000); // Every 5 seconds
  });

  bot.on('kicked', (reason) => console.log(`Bot ${bot.username} kicked: ${reason}`));
  bot.on('error', (err) => console.log(`Error with bot ${bot.username}: ${err}`));
}

// Launch multiple bots with a delay to avoid overload
const botCount = 2000; // Adjust as needed
for (let i = 0; i < botCount; i++) {
  setTimeout(() => createBot(i + 1), i * 100); // Stagger each bot by 2 seconds
}